<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;

class PurchaseOrders extends Model
{
    protected $fillable = [
        'po_number',
        'supplier_id',
        'category', // import / local
        'shipping_line_id',
        'po_date',
        'currency',
        'exchange_rate',
        'incoterm',
        'payment_term',
        'delivery_date',
        'arrival_date',
        'status',
    ];

    protected $casts = [
        'po_date' => 'datetime',
        'delivery_date' => 'datetime',
        'arrival_date' => 'datetime',
    ];

    public function supplier(): BelongsTo
    {
        return $this->belongsTo(Suppliers::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(PurchaseOrderItems::class, 'purchase_order_id');
    }

    public function shipments(): BelongsToMany
    {
        return $this->belongsToMany(Shipments::class, 'shipment_purchase_orders', 'purchase_order_id', 'shipment_id')
            ->withTimestamps();
    }

    public function localShipments(): HasMany
    {
        return $this->hasMany(LocalShipments::class, 'purchase_order_id');
    }

    public function localShipmentItems(): HasMany
    {
        return $this->hasMany(LocalShipmentItem::class, 'purchase_order_id');
    }

    public function allocatedLocalShipments(): HasManyThrough
    {
        return $this->hasManyThrough(
            LocalShipments::class,
            LocalShipmentItem::class,
            'purchase_order_id',
            'id',
            'id',
            'local_shipment_id',
        )->distinct();
    }
}
